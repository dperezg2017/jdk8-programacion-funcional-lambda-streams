package com.util;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UtilitarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(UtilitarioApplication.class, args);
	}

}
